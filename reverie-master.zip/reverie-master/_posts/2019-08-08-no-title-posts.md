---
layout: post
title: ""
categories: Miscellaneous
---
Sometimes, your post just stands for itself and doesn't need a title. And that's fine, too!